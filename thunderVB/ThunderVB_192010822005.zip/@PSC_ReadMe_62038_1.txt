Title: ThunderVB - First Release
Description: ThunderVB is an add-in for VB6. ThunderVB let's you embed Asm and C instructions directly in you VB source programs. Furthermore ThunVB let's you create a true StdCall Dlls.
Moreover ThunVB can extend VB IDE to a basic Asm/C code editor. That means it can do syntax-highlighting of Asm/C keywords and supports intelli-sense for InlineAsm code as well.
See the screenshots bellow.
--- ThunderVB Development Team [ drkIIRaziel &amp; Libor ] ---
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=62038&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
