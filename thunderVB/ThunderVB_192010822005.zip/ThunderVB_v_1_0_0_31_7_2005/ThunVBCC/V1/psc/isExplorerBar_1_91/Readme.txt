If you want to add visual Styles to VB, you can drop the vb6.exe.MANIFEST file to you VB Directory. 
This will also let you use visual styles in the VB IDE.
If you can use a MANIFEST file for your projects you can rename the ExplorerBarLiteTest.exe.MANIFEST and copy It to your App directory.
