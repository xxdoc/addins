Title: isExplorerBar 1.91  - The Explorer Bar Control. Updated: 2004-08-12
Description: Just See the Screenshot!. Have You ever wanted 
to use in your apps a control like the left bar 
in the explorer? there are some controls like 
that on the net, but they have too many 
dependences. isExplorerBar is a SINGLE FILE 
CONTROL and has almost NO DEPENDENCES (actually 
runs without extra dependences in a new VB 
Project) And uses THE REAL theme apareance or 
emulates it when no theme data aviable, 
everything is done in Runtime, using UxTheme.dll 
(included in WinXP). no extra dll's or 
subclasing cls modules, a single file control 
that has everything you need to make your apps 
look better. I've put a lot of work on this. 
please donwnload and tellme what you think. I've 
created a webpage for this control. includes 
some help, comments and extra info about It. 
please comments, sugestions and of course, 
votes are wellcome. 
************************************************* 
Lot Of Updates, Current version: 1.91
Feedback comments, are wellcome. Visit the page for versions history.
Best Regards to everyone.
Fred.cpp
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=53572&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
