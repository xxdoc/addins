Title: UniLabel - Unicode capable label
Description: You probably have had a need for a unicode label sometime. And maybe need for a label that doesn't blink all the time. I made this usercontrol so you can easily without any hacks have unicode text in your programs. Just include the usercontrol in your project and you're ready to go with it. *** Features: unicode capability under NT4/2000/XP, all the events and properties the default VB label has, autoredraw to enabled/disable blinking. The code is fully commented and being a rather simple control, it should be easy to learn how to make usercontrols. One API call is also introduced. *** Comments and votes welcome - the more interest, the more likely I'm to do more FREE unicode controls :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=56259&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
