Title: HzxY OptionButton Updated 20030105
Description: There are two bugs in the first version of HzxY OptionButton. The first causes it can not support Unicode, and the second causes it can not be painted correctly. Now, I've fix these bugs and re-upload it.
There are some XP-like OptionButtons. But lots of them have bug that will cause wrong values of all the other Options when one OptionButton's value is changed. The most significant improvement of HzxY Option has got rid of this bug, and support HzxY Option Array.
XP-like OptionButton, AutoResize according to "Caption" and "Font", Auto "BackColor" and "ForeColor".
NO Timer, NO ImageBox, NO Label, that is HzxY OptionButton.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=41865&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
