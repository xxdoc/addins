Title: Cool XP ProgressBar 2.0 (MultiStyle ProgressBar)
Description: The New Release of the Awesome XP Progress Bar is now available.
The new control offers more detailed painted controls, with more OS capability, now supports NT4, Also included the Media Player Progress Bar Style, and many others.
The Control itself as it predecessor does not need any dependency file and its very light in size.
Now It haves 8 Styles to choose from. 
The 5 New Styles are Limited to horizontal Orientation as I don�t use vertical very often , but if you like using it just code it your self, the code is very easy to follow and very understandable .
You are free to use this code on any way you wish, on commercial apps, on freeware or any other except selling the code claiming that is yours. 
Enjoy!
If you have any question, you can contact me on my e-mail 
sistec_de_juarez@hotmail.com or mflores@ansell.com
Feedback is Welcome
14 September 
New Style ::: "" METALLIC XP"" 
Added Font capability

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=56151&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
