Title: HzxY CheckBox Updated
Description: There is one bug in the first version of HzxY CheckBox causes it can not support Unicode. Now, I've fixed this bug and re-upload it.
XP-like CheckBox, AutoResize according to "Caption" and "Font", Auto "BackColor" and "ForeColor".
NO Timer, NO ImageBox, NO Label, that is HzxY CheckBox.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=41864&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
