Title: [!!!!!  XTab a complete Tab ActiveX control written from scratch  Updated -Now Supports Icons !!!!!]
Description: XTab is an ActiveX Control which can be used as a substitute for the Microsoft Tabbed Dialog/Property Page Control. XTab uses subclassing to achieve same design-time switching effect as MS Tab control does. XTab is highly customizable and provides many standard themes like XP,Visual Studio 2003 .Net, Rounded Tabs, Owner Drawn, Iconed theme etc. And best of all it has no external dependencies to subclassing dlls or common dialog etc controls. Optimized code for flicker free drawing. New themes can be easily added by simply implementing the ITheme Interface. Featured Property Page for easily setting properties.
Supports Individual Tab Enabling/Disabling.
Now supports Icons in all the themes. Also we can use PictureSize,PictureAlignment and MaskColor property to customize the Interface. Updated Property page too for better UI. Added a method to allow copying images from any compatible ImageList Control.
email:
nja91@yahoo.com
neeraj_agrawal_ind@rediffmail.com
If you like the code please leave a comment/vote. :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=56462&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
