Title: isButton 3.0 With Multiple Visual Styles, and more features. Updated: 2004-sep-15
Description: Do you want to change the style of your boring command buttons? try this cuztomizable button, drawn by code, baloon tooltips, 10 Visual Styles( winXP, Office XP, Mac OSX and more!), customizable caption and icon align and more! See screenshot. Also Includes a very creative way to show a about box Without add a extra form (using some api calls). The button is a single file control, without more dependences than VB Itself. uses Paul Caton Self subclasser: ' http://www.planetsourcecode.com/vb/scripts/ShowCode.asp?txtCodeId=54117&lngWId=1 Feedback Is highly apreciated. I'm working on the MacOSX style, since I need a faster way to draw It. Please coment. also, votes are wellcome. I've made a page for the control: http://www.geocities.com/isbutton3/ 
Update Includes lot of fixes and Checkbox behavior and Value property. If you want a Multy style ComboBox try SComboBox ( http://www.planet-source-code.com/vb/scripts/ShowCode.asp?lngWId=1&txtCodeId=56157 )
Regards and Have fun
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=56053&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
